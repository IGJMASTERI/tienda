const enc = new TextEncoder();
export const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
});
export const emailOk = (e) => typeof e === 'string' && e.length <= 120 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
export const aleatorio = (n = 16) => hex(crypto.getRandomValues(new Uint8Array(n)));
export async function hashClave(clave, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(clave), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 100000, hash: 'SHA-256' }, key, 256);
  return hex(bits);
}
export function iguales(a, b) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
export async function crearSesion(env, email) {
  const token = aleatorio(32);
  await env.USUARIOS.put('s:' + token, email, { expirationTtl: 60 * 60 * 24 * 30 });
  return token;
}
export async function emailDeSesion(env, request) {
  const h = request.headers.get('Authorization') || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!/^[a-f0-9]{64}$/.test(t)) return null;
  return await env.USUARIOS.get('s:' + t);
}
export const sinKV = () => json({ ok: false, codigo: 'sin_kv', error: 'Falta conectar el almacenamiento de cuentas.' }, 500);
