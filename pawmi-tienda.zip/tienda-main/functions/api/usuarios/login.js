import { json, hashClave, iguales, crearSesion, sinKV } from '../../_lib/cuentas.js';

export async function onRequestPost({ request, env }) {
  if (!env.USUARIOS) return sinKV();
  let b; try { b = await request.json(); } catch { return json({ ok: false, error: 'Solicitud inválida.' }, 400); }
  const email = String(b.email || '').trim().toLowerCase();
  const clave = String(b.password || '');
  const kIntentos = 'f:' + email;
  const intentos = parseInt((await env.USUARIOS.get(kIntentos)) || '0', 10);
  if (intentos >= 8) return json({ ok: false, error: 'Demasiados intentos. Espera 15 minutos.' }, 429);
  const raw = await env.USUARIOS.get('u:' + email);
  const u = raw ? JSON.parse(raw) : null;
  const ok = u && iguales(await hashClave(clave, u.salt), u.hash);
  if (!ok) {
    await env.USUARIOS.put(kIntentos, String(intentos + 1), { expirationTtl: 900 });
    return json({ ok: false, error: 'Correo o contraseña incorrectos.' }, 401);
  }
  await env.USUARIOS.delete(kIntentos);
  return json({ ok: true, token: await crearSesion(env, email) });
}
