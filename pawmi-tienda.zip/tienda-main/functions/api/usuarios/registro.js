import { json, emailOk, aleatorio, hashClave, crearSesion, sinKV } from '../../_lib/cuentas.js';

export async function onRequestPost({ request, env }) {
  if (!env.USUARIOS) return sinKV();
  let b; try { b = await request.json(); } catch { return json({ ok: false, error: 'Solicitud inválida.' }, 400); }
  const email = String(b.email || '').trim().toLowerCase();
  const clave = String(b.password || '');
  if (!emailOk(email)) return json({ ok: false, error: 'Escribe un correo válido.' }, 400);
  if (clave.length < 8 || clave.length > 100) return json({ ok: false, error: 'La contraseña debe tener entre 8 y 100 caracteres.' }, 400);
  if (await env.USUARIOS.get('u:' + email)) return json({ ok: false, error: 'Ya existe una cuenta con ese correo.' }, 409);
  const salt = aleatorio(16);
  await env.USUARIOS.put('u:' + email, JSON.stringify({ salt, hash: await hashClave(clave, salt), creado: new Date().toISOString() }));
  return json({ ok: true, token: await crearSesion(env, email) });
}
