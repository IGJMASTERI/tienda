import { json, emailDeSesion, sinKV } from '../../_lib/cuentas.js';

export async function onRequestGet({ request, env }) {
  if (!env.USUARIOS) return sinKV();
  const email = await emailDeSesion(env, request);
  if (!email) return json({ ok: false, error: 'Sesión no válida.' }, 401);
  const raw = await env.USUARIOS.get('p:' + email);
  return json({ ok: true, pedidos: raw ? JSON.parse(raw) : [] });
}

export async function onRequestPost({ request, env }) {
  if (!env.USUARIOS) return sinKV();
  const email = await emailDeSesion(env, request);
  if (!email) return json({ ok: false, error: 'Sesión no válida.' }, 401);
  let b; try { b = await request.json(); } catch { return json({ ok: false, error: 'Solicitud inválida.' }, 400); }
  if (!Array.isArray(b.pedidos)) return json({ ok: false, error: 'Faltan los pedidos.' }, 400);
  const raw = await env.USUARIOS.get('p:' + email);
  const lista = raw ? JSON.parse(raw) : [];
  const ids = new Set(lista.map((p) => p.id));
  for (const p of b.pedidos.slice(0, 20)) {
    const id = String(p.id || '').replace(/[^a-zA-Z0-9_]/g, '').slice(0, 40);
    if (!id || ids.has(id)) continue;
    ids.add(id);
    lista.push({
      id, mascota: String(p.mascota || '').slice(0, 80), producto: String(p.producto || 'Placa NFC').slice(0, 80),
      total: Math.max(0, Math.min(10000000, Number(p.total) || 0)), fecha: new Date().toISOString(), estado: 'Recibido'
    });
  }
  await env.USUARIOS.put('p:' + email, JSON.stringify(lista.slice(-200)));
  return json({ ok: true });
}
